package com.javatechie.client;

import com.javatechie.dto.Customer;
import org.springframework.stereotype.Service;
import org.springframework.web.service.annotation.*;

import java.util.List;

@HttpExchange("/customersInfo")
public interface CustomerClientService {

    @GetExchange
     List<Customer> getAllCustomers();


}
